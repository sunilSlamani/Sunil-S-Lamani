import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, AlertTriangle, CheckCircle, Loader2, X } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  scanType: "link" | "sms" | "call";
}

interface ScanResult {
  isThreat: boolean;
  severity: "safe" | "low" | "medium" | "high" | "critical";
  threatType: string;
  reason: string;
  recommendation: string;
}

export function ScanModal({ isOpen, onClose, scanType }: ScanModalProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);

  const handleScan = async () => {
    if (!content.trim()) {
      toast({
        title: "Error",
        description: "Please enter content to scan",
        variant: "destructive",
      });
      return;
    }

    setIsScanning(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("scan-threat", {
        body: { content, type: scanType },
      });

      if (error) throw error;

      setResult(data as ScanResult);
    } catch (error) {
      console.error("Scan error:", error);
      toast({
        title: "Scan Failed",
        description: "Unable to scan content. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsScanning(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "safe":
        return "text-success";
      case "low":
        return "text-warning";
      case "medium":
      case "high":
      case "critical":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };

  const getSeverityIcon = (severity: string) => {
    return severity === "safe" ? (
      <CheckCircle className="w-16 h-16 text-success" />
    ) : (
      <AlertTriangle className="w-16 h-16 text-destructive" />
    );
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl"
        >
          <Card className="glass p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-foreground">
                  {scanType === "link" && "Scan Link or QR Code"}
                  {scanType === "sms" && "Scan SMS Message"}
                  {scanType === "call" && "Check Phone Number"}
                </h2>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-muted-foreground"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {!result ? (
              <>
                <Textarea
                  placeholder={
                    scanType === "link"
                      ? "Paste URL or QR code text here..."
                      : scanType === "sms"
                      ? "Paste message content here..."
                      : "Enter phone number..."
                  }
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-[150px] glass"
                  disabled={isScanning}
                />

                <div className="flex gap-3 justify-end">
                  <Button variant="outline" onClick={onClose} disabled={isScanning}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleScan}
                    disabled={isScanning || !content.trim()}
                    className="bg-primary text-primary-foreground"
                  >
                    {isScanning ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Scanning...
                      </>
                    ) : (
                      "Scan Now"
                    )}
                  </Button>
                </div>
              </>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex flex-col items-center gap-4 text-center">
                  {getSeverityIcon(result.severity)}
                  <div>
                    <h3 className={`text-2xl font-bold ${getSeverityColor(result.severity)}`}>
                      {result.isThreat ? "Threat Detected!" : "Safe Content"}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Severity: {result.severity.toUpperCase()} | Type: {result.threatType}
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="glass p-4 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Analysis</h4>
                    <p className="text-muted-foreground text-sm">{result.reason}</p>
                  </div>

                  <div className="glass p-4 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Recommendation</h4>
                    <p className="text-muted-foreground text-sm">{result.recommendation}</p>
                  </div>
                </div>

                <div className="flex gap-3 justify-end">
                  <Button
                    onClick={() => {
                      setResult(null);
                      setContent("");
                    }}
                    variant="outline"
                  >
                    Scan Another
                  </Button>
                  <Button onClick={onClose}>Close</Button>
                </div>
              </motion.div>
            )}
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}