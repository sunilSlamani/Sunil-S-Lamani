import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ActivationScreen } from "@/components/ActivationScreen";
import { Dashboard } from "@/components/Dashboard";
import "@/i18n";

const Index = () => {
  const [isActive, setIsActive] = useState(false);
  const [showTransition, setShowTransition] = useState(false);

  useEffect(() => {
    // Load saved activation state
    const savedState = localStorage.getItem('guardian-active');
    if (savedState === 'true') {
      setIsActive(true);
      document.body.classList.add('active');
    }
  }, []);

  const handleActivate = () => {
    setShowTransition(true);
    setTimeout(() => {
      setIsActive(true);
      localStorage.setItem('guardian-active', 'true');
      setShowTransition(false);
      // Add green theme class to body
      document.body.classList.add('active');
    }, 1500);
  };

  const handleDeactivate = () => {
    setIsActive(false);
    localStorage.setItem('guardian-active', 'false');
    // Remove green theme class from body
    document.body.classList.remove('active');
  };

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {showTransition && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center active-gradient"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.2, 1] }}
              transition={{ duration: 1.5 }}
              className="text-white text-6xl font-bold"
            >
              ✓
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {!isActive ? (
        <ActivationScreen onActivate={handleActivate} />
      ) : (
        <Dashboard onDeactivate={handleDeactivate} />
      )}
    </div>
  );
};

export default Index;
