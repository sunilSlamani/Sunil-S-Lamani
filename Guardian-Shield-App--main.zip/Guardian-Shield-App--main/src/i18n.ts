import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      "app.name": "Guardian Shield",
      "app.tagline": "Your Digital Protection",
      "activation.title": "Activate Protection",
      "activation.subtitle": "Press ON to enable full security scanning",
      "activation.button": "ON",
      "activation.emergency": "Emergency Help",
      "activation.report": "Quick Report",
      "dashboard.active": "Protection Active",
      "dashboard.scanning": "Auto-scan running in background",
      "feature.scan": "Scan Link / QR",
      "feature.scan.desc": "Verify URLs and QR codes instantly",
      "feature.report": "Report Fraud",
      "feature.report.desc": "Submit suspicious activity",
      "feature.document": "Document Guard",
      "feature.document.desc": "Verify upload safety",
      "feature.password": "Password Vault",
      "feature.password.desc": "Secure password storage",
      "feature.call": "Call Protection",
      "feature.call.desc": "Scan incoming calls",
      "feature.sms": "SMS Protection",
      "feature.sms.desc": "Auto-scan text messages",
      "feature.community": "Community Reports",
      "feature.community.desc": "View reported scams",
      "stats.blocked": "Threats Blocked",
      "stats.scans": "Scans Performed",
      "stats.reports": "Community Reports",
    }
  },
  kn: {
    translation: {
      "app.name": "ಗಾರ್ಡಿಯನ್ ಶೀಲ್ಡ್",
      "app.tagline": "ನಿಮ್ಮ ಡಿಜಿಟಲ್ ರಕ್ಷಣೆ",
      "activation.title": "ರಕ್ಷಣೆಯನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿ",
      "activation.subtitle": "ಸಂಪೂರ್ಣ ಭದ್ರತಾ ಸ್ಕ್ಯಾನಿಂಗ್ ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ON ಒತ್ತಿರಿ",
      "activation.button": "ON",
      "activation.emergency": "ತುರ್ತು ಸಹಾಯ",
      "activation.report": "ತ್ವರಿತ ವರದಿ",
      "dashboard.active": "ರಕ್ಷಣೆ ಸಕ್ರಿಯ",
      "dashboard.scanning": "ಹಿನ್ನೆಲೆಯಲ್ಲಿ ಸ್ವಯಂ-ಸ್ಕ್ಯಾನ್ ನಡೆಯುತ್ತಿದೆ",
      "feature.scan": "ಲಿಂಕ್ / QR ಸ್ಕ್ಯಾನ್",
      "feature.scan.desc": "URLs ಮತ್ತು QR ಕೋಡ್‌ಗಳನ್ನು ತಕ್ಷಣ ಪರಿಶೀಲಿಸಿ",
      "feature.report": "ವಂಚನೆಯನ್ನು ವರದಿ ಮಾಡಿ",
      "feature.report.desc": "ಅನುಮಾನಾಸ್ಪದ ಚಟುವಟಿಕೆಯನ್ನು ಸಲ್ಲಿಸಿ",
      "feature.document": "ದಾಖಲೆ ರಕ್ಷಕ",
      "feature.document.desc": "ಅಪ್‌ಲೋಡ್ ಸುರಕ್ಷತೆಯನ್ನು ಪರಿಶೀಲಿಸಿ",
      "feature.password": "ಪಾಸ್‌ವರ್ಡ್ ವಾಲ್ಟ್",
      "feature.password.desc": "ಸುರಕ್ಷಿತ ಪಾಸ್‌ವರ್ಡ್ ಸಂಗ್ರಹಣೆ",
      "feature.call": "ಕರೆ ರಕ್ಷಣೆ",
      "feature.call.desc": "ಒಳಬರುವ ಕರೆಗಳನ್ನು ಸ್ಕ್ಯಾನ್ ಮಾಡಿ",
      "feature.sms": "SMS ರಕ್ಷಣೆ",
      "feature.sms.desc": "ಪಠ್ಯ ಸಂದೇಶಗಳನ್ನು ಸ್ವಯಂ-ಸ್ಕ್ಯಾನ್",
      "feature.community": "ಸಮುದಾಯ ವರದಿಗಳು",
      "feature.community.desc": "ವರದಿ ಮಾಡಿದ ವಂಚನೆಗಳನ್ನು ನೋಡಿ",
      "stats.blocked": "ಬೆದರಿಕೆಗಳನ್ನು ನಿರ್ಬಂಧಿಸಲಾಗಿದೆ",
      "stats.scans": "ಸ್ಕ್ಯಾನ್‌ಗಳು ನಿರ್ವಹಿಸಲಾಗಿದೆ",
      "stats.reports": "ಸಮುದಾಯ ವರದಿಗಳು",
    }
  },
  hi: {
    translation: {
      "app.name": "गार्डियन शील्ड",
      "app.tagline": "आपकी डिजिटल सुरक्षा",
      "activation.title": "सुरक्षा सक्रिय करें",
      "activation.subtitle": "पूर्ण सुरक्षा स्कैनिंग सक्षम करने के लिए ON दबाएं",
      "activation.button": "ON",
      "activation.emergency": "आपातकालीन सहायता",
      "activation.report": "त्वरित रिपोर्ट",
      "dashboard.active": "सुरक्षा सक्रिय",
      "dashboard.scanning": "पृष्ठभूमि में ऑटो-स्कैन चल रहा है",
      "feature.scan": "लिंक / QR स्कैन",
      "feature.scan.desc": "URLs और QR कोड तुरंत सत्यापित करें",
      "feature.report": "धोखाधड़ी की रिपोर्ट करें",
      "feature.report.desc": "संदिग्ध गतिविधि सबमिट करें",
      "feature.document": "दस्तावेज़ गार्ड",
      "feature.document.desc": "अपलोड सुरक्षा सत्यापित करें",
      "feature.password": "पासवर्ड वॉल्ट",
      "feature.password.desc": "सुरक्षित पासवर्ड स्टोरेज",
      "feature.call": "कॉल सुरक्षा",
      "feature.call.desc": "आने वाली कॉल स्कैन करें",
      "feature.sms": "SMS सुरक्षा",
      "feature.sms.desc": "टेक्स्ट संदेश ऑटो-स्कैन",
      "feature.community": "समुदाय रिपोर्ट",
      "feature.community.desc": "रिपोर्ट किए गए घोटाले देखें",
      "stats.blocked": "खतरे ब्लॉक किए गए",
      "stats.scans": "स्कैन किए गए",
      "stats.reports": "समुदाय रिपोर्ट",
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
