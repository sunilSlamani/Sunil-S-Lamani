
# 🛡️ Guardian Shield – Smart Real-Time Security & Fraud Prevention App  

> **A multilingual cybersecurity solution for protecting users from scams, frauds, and data theft.**

---

## 🌍 Overview  

**Guardian Shield** is a next-generation security application that helps users stay safe from **online scams, phishing attacks, fake calls, and malicious links**.  
It offers **real-time monitoring**, **auto-scan detection**, and **instant alerts** to protect your personal information across messages, calls, and websites.  
The app combines smart automation, community reporting, and privacy-first design to build a safer digital experience for everyone.  

---

## ✨ Key Features  

### 🔒 **Security & Protection**
- **Real-Time Threat Detection:** Continuously monitors your device for fraudulent links, scam calls, and suspicious SMS messages.  
- **Auto Scan Mode:** Automatically scans new messages, downloads, and websites in the background.  
- **Instant Scam Pop-ups:** Displays warning overlays when a suspicious call, link, or message is detected.  
- **Document Guard:** Prevents you from uploading sensitive files to unverified websites.  
- **Auto-Blocking & Quarantine:** Blocks unsafe downloads or quarantines risky files instantly.  
- **Call & Message Protection:** Detects scam calls and phishing texts using pattern recognition.  

---

### 🔑 **User Tools**
- **Password Vault:** Stores your credentials securely using AES-256 encryption.  
- **Safe Browsing Mode:** In-app browser that checks every website before you visit.  
- **Community Reports:** Share and view verified scam reports from other users.  
- **Security Dashboard:** Displays protection stats, threat count, and user risk score.  
- **Weekly Security Reports:** Summarizes threats blocked and safety tips via email.  

---

### 🌐 **Accessibility & Languages**
- **Multilingual Interface:** Supports **English**, **ಕನ್ನಡ (Kannada)**, and **हिन्दी (Hindi)**.  
- **Instant Language Switch:** Change languages instantly without reloading the app.  
- **Consistent Experience:** Saves user’s last language preference using local storage.  

---

### ⚙️ **Advanced Automation**
- **Auto-Scan Service:** Runs continuously once protection is ON.  
- **Smart Alerts:** Warns users with sound/vibration when detecting scams.  
- **Community Intelligence:** Uses aggregated reports to predict emerging scam trends.  
- **Adaptive Protection:** Learns from user behavior to improve accuracy over time.  

---

## 💻 Tech Stack  

| Layer | Technology Used |
|--------|----------------|
| **Frontend** | React.js / Flutter, TailwindCSS |
| **Backend** | Node.js (Express), Firebase / MongoDB |
| **AI Service** | Python |
| **Authentication** | Firebase Auth|
| **Database** | Firebase Firestore / MongoDB Atlas |
| **Notifications** | Firebase Cloud Messaging (FCM) |
| **Localization** | react-i18next (for English, Kannada, Hindi) |

---

## 🧠 Core Modules & APIs  

| Module | Description |
|--------|-------------|
| **Authentication** | Register, login, and manage user sessions securely. |
| **Fraud Detection** | Scan and analyze URLs, SMS, and calls for suspicious content. |
| **Auto-Scan Service** | Continuously scans in the background for threats. |
| **Community Reports** | Users can submit and view fraud alerts. |
| **Document Guard** | Verifies site legitimacy before allowing file uploads. |
| **Password Vault** | Stores encrypted passwords and checks for breaches. |
| **Notification System** | Sends alerts when scams or threats are detected. |
| **Weekly Summary** | Emails users their weekly safety report. |

---

## 🧩 App Flow  

1. **Splash Screen:** Shows the logo and brief animation.  
2. **Pre-Home Activation Screen:** Large circular **ON** button to enable full protection.  
   - Before ON: only Emergency and Quick Report are available.  
   - After ON: the app activates background scanning and turns green.  
3. **Home Dashboard:** Displays all features with a modern, glowing UI.  
4. **Auto-Scan Active:** Monitors all system events (calls, links, downloads).  
5. **Alert Pop-up:** Appears immediately if a scam or malicious item is detected.  
6. **Dashboard Overview:** Shows total threats blocked, security score, and trends.  

---

## 🧱 Backend Architecture  

- **Node.js + Express Server**
  - RESTful API endpoints for user data, settings, and reports.  
- **AI Detection Microservice (Python Flask)**
  - NLP-based URL and text classification engine.  
  - Detects scam patterns like phishing links, fake numbers, or spam phrases.  
- **Database**
  - Stores user data, reports, and threat logs securely.  
- **Notifications**
  - Firebase Cloud Messaging for real-time scam pop-ups and weekly digests.  

---

## 📊 System Overview  

```plaintext
 ┌──────────────────────────┐
 │        Frontend          │
 │  (React / Flutter App)   │
 └────────────┬─────────────┘
              │ REST API
 ┌────────────▼─────────────┐
 │        Backend API       │
 │   Node.js + Express      │
 ├────────────┬─────────────┤
 │   Fraud Detection AI     │
 │      (Python  Service)   │
 ├────────────┬─────────────┤
 │  Firebase / MongoDB DB   │
 │ Stores users, reports,   │
 │   and scam statistics    │
 └──────────────────────────┘
