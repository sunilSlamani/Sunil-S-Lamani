import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, AlertCircle, Flag } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { LanguageSelector } from "./LanguageSelector";

interface ActivationScreenProps {
  onActivate: () => void;
}

export function ActivationScreen({ onActivate }: ActivationScreenProps) {
  const { t } = useTranslation();
  const [isHovering, setIsHovering] = useState(false);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden shield-pattern">
      {/* Language Selector - Fixed Top Right */}
      <div className="fixed top-6 right-6 z-50">
        <LanguageSelector />
      </div>

      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-card" />
      
      {/* Shield Pattern Overlay */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,hsl(var(--primary))_1px,transparent_1px)] bg-[length:50px_50px]" />
      </div>

      {/* Main Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 flex flex-col items-center gap-12 px-6"
      >
        {/* Logo & Title */}
        <div className="text-center space-y-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
          >
            <Shield className="w-20 h-20 mx-auto text-primary" />
          </motion.div>
          <h1 className="text-5xl font-bold text-foreground">{t('app.name')}</h1>
          <p className="text-xl text-muted-foreground">{t('app.tagline')}</p>
        </div>

        {/* Activation Message */}
        <div className="text-center space-y-2 max-w-md">
          <h2 className="text-2xl font-semibold text-foreground">
            {t('activation.title')}
          </h2>
          <p className="text-muted-foreground">
            {t('activation.subtitle')}
          </p>
        </div>

        {/* Large ON Button */}
        <motion.div
          onHoverStart={() => setIsHovering(true)}
          onHoverEnd={() => setIsHovering(false)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <button
            onClick={onActivate}
            className="relative w-48 h-48 rounded-full glass border-4 border-primary/30 flex items-center justify-center group transition-all duration-300 hover:border-primary"
            style={{
              boxShadow: isHovering 
                ? '0 0 60px hsl(var(--primary) / 0.5), inset 0 0 30px hsl(var(--primary) / 0.1)' 
                : '0 0 30px hsl(var(--primary) / 0.3), inset 0 0 15px hsl(var(--primary) / 0.05)'
            }}
          >
            <AnimatePresence>
              {isHovering && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1.5, opacity: 0 }}
                  exit={{ scale: 0 }}
                  transition={{ duration: 0.6, repeat: Infinity }}
                  className="absolute inset-0 rounded-full border-4 border-primary"
                />
              )}
            </AnimatePresence>
            <span className="text-6xl font-bold text-primary group-hover:text-primary/90">
              {t('activation.button')}
            </span>
          </button>
        </motion.div>

        {/* Emergency Actions - Active */}
        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            className="glass border-destructive/50 text-destructive hover:bg-destructive/10"
          >
            <AlertCircle className="w-4 h-4 mr-2" />
            {t('activation.emergency')}
          </Button>
          <Button
            variant="outline"
            className="glass border-warning/50 text-warning hover:bg-warning/10"
          >
            <Flag className="w-4 h-4 mr-2" />
            {t('activation.report')}
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
