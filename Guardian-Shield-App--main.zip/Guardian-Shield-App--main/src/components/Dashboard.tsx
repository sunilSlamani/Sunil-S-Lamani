import { motion } from "framer-motion";
import { Shield, Link2, Flag, FileCheck, Lock, Phone, MessageSquare, Users, TrendingUp } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Card } from "@/components/ui/card";
import { LanguageSelector } from "./LanguageSelector";
import { ScanModal } from "./ScanModal";
import { useState } from "react";

interface DashboardProps {
  onDeactivate: () => void;
}

export function Dashboard({ onDeactivate }: DashboardProps) {
  const { t } = useTranslation();
  const [stats] = useState({
    threatsBlocked: 247,
    scansPerformed: 1853,
    communityReports: 12439
  });
  const [scanModal, setScanModal] = useState<{ isOpen: boolean; type: "link" | "sms" | "call" }>({
    isOpen: false,
    type: "link"
  });

  const features = [
    { 
      icon: Link2, 
      title: t('feature.scan'), 
      desc: t('feature.scan.desc'), 
      color: 'text-primary',
      onClick: () => setScanModal({ isOpen: true, type: "link" })
    },
    { icon: Flag, title: t('feature.report'), desc: t('feature.report.desc'), color: 'text-destructive' },
    { icon: FileCheck, title: t('feature.document'), desc: t('feature.document.desc'), color: 'text-success' },
    { icon: Lock, title: t('feature.password'), desc: t('feature.password.desc'), color: 'text-accent' },
    { 
      icon: Phone, 
      title: t('feature.call'), 
      desc: t('feature.call.desc'), 
      color: 'text-warning',
      onClick: () => setScanModal({ isOpen: true, type: "call" })
    },
    { 
      icon: MessageSquare, 
      title: t('feature.sms'), 
      desc: t('feature.sms.desc'), 
      color: 'text-primary',
      onClick: () => setScanModal({ isOpen: true, type: "sms" })
    },
    { icon: Users, title: t('feature.community'), desc: t('feature.community.desc'), color: 'text-muted-foreground' },
  ];

  return (
    <div className="min-h-screen shield-pattern">
      {/* Header */}
      <header className="glass sticky top-0 z-50 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-success shield-glow" />
            <div>
              <h1 className="text-xl font-bold text-foreground">{t('app.name')}</h1>
              <p className="text-xs text-muted-foreground">{t('app.tagline')}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <LanguageSelector />
            <button
              onClick={onDeactivate}
              className="px-4 py-2 rounded-lg bg-destructive/10 text-destructive border border-destructive/30 hover:bg-destructive/20 transition-colors text-sm font-medium"
            >
              Deactivate
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12 space-y-12">
        {/* Active Status Banner */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="active-gradient rounded-2xl p-8 text-center shield-glow"
        >
          <Shield className="w-16 h-16 mx-auto mb-4 text-white" />
          <h2 className="text-3xl font-bold text-white mb-2">
            {t('dashboard.active')}
          </h2>
          <p className="text-white/90">
            {t('dashboard.scanning')}
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard
            icon={Shield}
            label={t('stats.blocked')}
            value={stats.threatsBlocked}
            color="text-success"
          />
          <StatCard
            icon={TrendingUp}
            label={t('stats.scans')}
            value={stats.scansPerformed}
            color="text-primary"
          />
          <StatCard
            icon={Users}
            label={t('stats.reports')}
            value={stats.communityReports}
            color="text-accent"
          />
        </div>

        {/* Features Grid */}
        <div>
          <h3 className="text-2xl font-bold text-foreground mb-6">Security Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card 
                  className="glass p-6 hover:border-primary/50 transition-all cursor-pointer group"
                  onClick={feature.onClick}
                >
                  <feature.icon className={`w-10 h-10 mb-4 ${feature.color} group-hover:scale-110 transition-transform`} />
                  <h4 className="text-lg font-semibold text-foreground mb-2">
                    {feature.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {feature.desc}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <ScanModal 
        isOpen={scanModal.isOpen}
        onClose={() => setScanModal({ ...scanModal, isOpen: false })}
        scanType={scanModal.type}
      />
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: any, label: string, value: number, color: string }) {
  return (
    <Card className="glass p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{label}</p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-3xl font-bold text-foreground"
          >
            {value.toLocaleString()}
          </motion.p>
        </div>
        <Icon className={`w-10 h-10 ${color}`} />
      </div>
    </Card>
  );
}
